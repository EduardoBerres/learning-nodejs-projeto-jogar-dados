var app = require('./config/server');

app.listen(3100, function(){
	console.log('A nossa aplicação de jogar dados está online.')
})